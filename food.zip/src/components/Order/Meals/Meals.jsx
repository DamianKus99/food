import { Fragment } from 'react';
import AvailableMeals from './AvailableMeals';

const Meals = () => {
  return (
    <Fragment>
      <AvailableMeals />
    </Fragment>
  );
};

export default Meals;
