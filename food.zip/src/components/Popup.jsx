import React from "react";
const Popup = props => {
  return (
    <div>
      <div>
        {props.content}
      </div>
    </div>
  );
};
 
export default Popup;