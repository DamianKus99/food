import React from "react";

const MainFooter = () => (
  <div className="main-footer">
    <p>Project Capybara ©{new Date().getFullYear()}</p>
  </div>
);

export default MainFooter;
