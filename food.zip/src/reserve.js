import React from "react";
import AppContainer from "./reservation/containers/AppContainer";
import "./reservation/styles/App1.css";

function Reserve() {
  return <AppContainer />;
}

export default Reserve;
