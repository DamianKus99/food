import { useEffect, useState } from 'react';

import Card from '../UI/Card';
import MealItem from './MealItem/MealItem';
import classes from '../../../styles/Order.module/Meals.module/AvailableMeals.module.scss';

const AvailableMeals = () => {
  const [meals, setMeals] = useState([]);
  const [meals2, setMeals2] = useState([]);
  const [meals3, setMeals3] = useState([]);
  const [meals4, setMeals4] = useState([]);
  const [isOpened, setIsOpened] = useState(false);
  const [isOpened2, setIsOpened2] = useState(false);
  const [isOpened3, setIsOpened3] = useState(false);
  const [isOpened4, setIsOpened4] = useState('lunch');
  const [isLoading, setIsLoading] = useState(true);
  const [httpError, setHttpError] = useState();
  const [type, setType] = useState('name-asc');

  useEffect(() => {
    const fetchMeals = async () => {
      const response = await fetch(
        'http://localhost:8080/api/food?'+type+'=true'
      );

      if (!response.ok) {
        throw new Error('Something went wrong!');
      }

      const responseData = await response.json();

      const loadedMeals = [];
      
      for (const key in responseData) {
        if(responseData[key].type==="dania-glowne"&&responseData[key].avaiable) {loadedMeals.push({
          id: responseData[key].foodItemId,
          id2: responseData[key].foodItemId,
          name: responseData[key].name,
          description: responseData[key].description,
          type: responseData[key].type,
          price: responseData[key].price,
        });
      }
      }
      console.log(loadedMeals);
      setMeals(loadedMeals);
      setMeals2(loadedMeals);
      setIsLoading(false);
    };

    fetchMeals().catch((error) => {
      setIsLoading(false);
      setHttpError(error.message);
    });
  }, []);

  if (isLoading) {
    return (
      <section className={classes.MealsLoading}>
        <p>Loading...</p>
      </section>
    );
  }

  if (httpError) {
    return (
      <section className={classes.MealsError}>
        <p>{httpError}</p>
      </section>
    );
  }

const pressed = (value) => {

  setIsOpened4(value);
  console.log(value);
  maping('name-asc',value);
}




  const maping = async (value,value2) => {
    const response = await fetch(
      'http://localhost:8080/api/food?'+value+'=true'
    );
    console.log(response);

    if (!response.ok) {
      throw new Error('Something went wrong!');
    }

    const responseData = await response.json();

    const loadedMeals = [];
    
    for (const key in responseData) {
      if(responseData[key].type===value2&&responseData[key].avaiable) {loadedMeals.push({
        id: responseData[key].foodItemId,
        id2: responseData[key].foodItemId,
        name: responseData[key].name,
        description: responseData[key].description,
        type: responseData[key].type,
        price: responseData[key].price,
      });
    }
    }
    console.log(loadedMeals);
    setMeals(loadedMeals);
    setMeals2(loadedMeals);
    setIsLoading(false);
  };

  const maping2 = async (value) => {
    const response = await fetch(
      'http://localhost:8080/api/food?'+value+'=true'
    );
    console.log(response);

    if (!response.ok) {
      throw new Error('Something went wrong!');
    }

    const responseData = await response.json();

    const loadedMeals = [];
    
    for (const key in responseData) {
      if(responseData[key].type==="sniadanie"&&responseData[key].avaiable) {loadedMeals.push({
        id: responseData[key].foodItemId,
        id2: responseData[key].foodItemId,
        name: responseData[key].name,
        description: responseData[key].description,
        type: responseData[key].type,
        price: responseData[key].price,
      });
    }
    }
    console.log(loadedMeals);
    setMeals2(loadedMeals);
    setIsLoading(false);
  };

  const mealsList = meals.map((meal) => (
    <MealItem
      key={meal.id}
      id={meal.id}
      name={meal.name}
      //description={meal.description}
      type={meal.type}
      price={meal.price}
    />
  ));
  const mealsList2 = meals2.map((meal) => (
    <MealItem
      key={meal.id} 
      id={meal.id}
      name={meal.name}
      //description={meal.description}
      //type={meal.type}
      price={meal.price}
    />
  ));

  return (
    <section className={classes.meals}>
    <button onClick={ () => {pressed('dania-glowne');}}>Dania główne</button>
    <button onClick={ () => {pressed('sniadania');}}>Oferta śniadaniowa</button>
    <button onClick={ () => {pressed('zupy');}}>Zupy</button>
    <button onClick={ () => {pressed('napoje');}}>Napoje</button>
    <button onClick={ () => {pressed('desery');}}>Desery</button>
    <button onClick={ () => {pressed('salatki');}}>Sałatki</button>
      <form>
      <select 
        onChange={(event) => {maping(event.target.value,isOpened4)
      }
  }
      >    
        <option value="name-asc">Name A↓Z</option>
        <option value="name-desc">Name Z↑A</option>
        <option value="price-asc">Price A↓Z</option>
        <option value="price-desc">Price Z↑A</option>
      </select>
    </form>
      <Card>
        <ul>{mealsList}</ul>
      </Card>
    </section>

  );
};

export default AvailableMeals;
